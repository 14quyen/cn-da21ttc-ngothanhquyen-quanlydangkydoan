<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thêm Giảng Viên</title>
    <link rel="stylesheet" href="<?php echo base_url('assets/css/add.css'); ?>">
</head>
<body>
    <h1>Thêm Giảng Viên</h1>

    <form action="<?php echo base_url('giangvien/add_process'); ?>" method="POST">
    <input type="hidden" name="maTK" value="<?php echo $maTK; ?>">

    <label>Mã Giảng Viên:</label>
    <input type="text" name="maGV" required>

    <label>Tên Giảng Viên:</label>
    <input type="text" name="tenGV" required>

    <label>Số Điện Thoại:</label>
    <input type="text" name="sdt" required>

    <label>Email:</label>
    <input type="email" name="email" required>

    <button type="submit">Lưu Thông Tin</button>
</form>

</body>
</html>
