<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sửa Giảng Viên</title>
    <link rel="stylesheet" href="<?php echo base_url('assets/css/add.css'); ?>">
</head>
<body>
    <h1>Sửa Giảng Viên</h1>

    <form action="<?php echo base_url('giangvien/edit_process'); ?>" method="POST">
        <input type="hidden" name="maGV" value="<?php echo $giangvien->maGV; ?>">

        <label for="tenGV">Tên Giảng Viên:</label>
        <input type="text" name="tenGV" id="tenGV" value="<?php echo $giangvien->tenGV; ?>" required>

        <label for="sdt">Số Điện Thoại:</label>
        <input type="text" name="sdt" id="sdt" value="<?php echo $giangvien->sdt; ?>" required>

        <label for="email">Email:</label>
        <input type="email" name="email" id="email" value="<?php echo $giangvien->email; ?>" required>

        

        <button type="submit">Cập Nhật Giảng Viên</button>
    </form>
</body>
</html>
