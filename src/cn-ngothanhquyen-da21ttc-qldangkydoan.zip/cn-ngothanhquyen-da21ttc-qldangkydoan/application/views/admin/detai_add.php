<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thêm Đề Tài</title>
    <link rel="stylesheet" href="<?php echo base_url('assets/css/add.css'); ?>">
</head>
<body>
    <h1>Thêm Đề Tài</h1>

    <form action="<?php echo base_url('detai/add_process'); ?>" method="POST">
        <label for="tenDT">Tên Đề Tài:</label>
        <input type="text" name="tenDT" id="tenDT" required>

        <label for="mota">Mô Tả:</label>
        <textarea name="mota" id="mota" required></textarea>

        <label for="maGV">Mã Giảng Viên:</label>
        <input type="text" name="maGV" id="maGV" required>

        <label for="maLDT">Mã Loại Đề Tài:</label>
        <select name="maLDT" id="maLDT" required>
            <option value="">Chọn Loại Đề Tài</option>
            <?php foreach ($loaiDTS as $loaiDT): ?>
                <option value="<?php echo $loaiDT->maLDT; ?>"><?php echo $loaiDT->tenLDT; ?></option>
            <?php endforeach; ?>
        </select>

        <button type="submit">Thêm Đề Tài</button>
    </form>
</body>
</html>
