<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sửa Sinh Viên</title>
    <link rel="stylesheet" href="<?php echo base_url('assets/css/add.css'); ?>">
</head>
<body>
    <h1>Sửa Sinh Viên</h1>

    <form action="<?php echo base_url('sinhvien/edit_process/'.$sinhvien->maSV); ?>" method="POST">
        <label for="tenSV">Tên Sinh Viên:</label>
        <input type="text" name="tenSV" id="tenSV" value="<?php echo $sinhvien->tenSV; ?>" required>

        <label for="maLop">Lớp:</label>
        <input type="text" name="maLop" id="maLop" value="<?php echo $sinhvien->maLop; ?>" required>

        <label for="sdtSV">Số Điện Thoại:</label>
        <input type="text" name="sdtSV" id="sdtSV" value="<?php echo $sinhvien->sdtSV; ?>" required>

        <label for="emailSV">Email:</label>
        <input type="email" name="emailSV" id="emailSV" value="<?php echo $sinhvien->emailSV; ?>" required>

        <button type="submit">Cập Nhật Sinh Viên</button>
    </form>
</body>
</html>
