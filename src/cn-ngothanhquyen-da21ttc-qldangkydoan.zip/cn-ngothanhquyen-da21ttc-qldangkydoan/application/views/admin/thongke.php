<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thống Kê Đề Tài</title>
    <link rel="stylesheet" href="<?php echo base_url('assets/css/style.css'); ?>">
</head>
<body>
    <h1>Danh Sách Các Đề Tài Đã Đăng Ký</h1>

    <?php foreach ($loaiDTs as $loaiDT): ?>
        <h2><?php echo $loaiDT['loaiDT']->tenLDT; ?></h2>

        <table border="1">
            <thead>
                <tr>
                    <th>Mã Đề Tài</th>
                    <th>Tên Đề Tài</th>
                    <th>Mô Tả</th>
                    <th>Tên Giảng Viên</th>
                    <th>Tên Sinh Viên Đăng Ký</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($loaiDT['detais'] as $detai): ?>
                    <tr>
                        <td style="text-align: center;"><?php echo $detai->maDT; ?></td>
                        <td><?php echo $detai->tenDT; ?></td>
                        <td><?php echo $detai->mota; ?></td>
                        <td style="text-align: center;"><?php echo $detai->giangvien ? $detai->giangvien->tenGV : 'Không có giảng viên'; ?></td>
                        <td style="text-align: center;">
                            <?php if (count($detai->sinhvien) > 0): ?>
                                <?php foreach ($detai->sinhvien as $sinhvien): ?>
                                    <p><?php echo $sinhvien->tenSV; ?></p>
                                <?php endforeach; ?>
                            <?php else: ?>
                                Không có sinh viên đăng ký
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

    <?php endforeach; ?>
</body>
</html>
