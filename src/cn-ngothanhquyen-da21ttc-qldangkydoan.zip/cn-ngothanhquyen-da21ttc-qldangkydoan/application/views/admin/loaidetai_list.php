<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quản lý Loại Đề Tài</title>
    <link rel="stylesheet" href="<?php echo base_url('assets/css/style.css'); ?>">
</head>
<body>
    <h1>Quản lý Loại Đề Tài</h1>

    <!-- Nút thêm loại đề tài -->
    <a href="<?php echo base_url('loaidetai/add'); ?>" class="btn btn-primary">Thêm Loại Đề Tài</a>

    <!-- Bảng danh sách loại đề tài -->
    <table>
        <thead>
            <tr>
                <th>Mã Loại Đề Tài</th>
                <th>Tên Loại Đề Tài</th>
                <th>Hành Động</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($loaidetais as $loaidetai): ?>
            <tr>
                <td><?php echo $loaidetai->maLDT; ?></td>
                <td><?php echo $loaidetai->tenLDT; ?></td>
                <td>
                    <!-- Nút sửa loại đề tài -->
                    <a href="<?php echo base_url('loaidetai/edit/'.$loaidetai->maLDT); ?>" class="btn btn-warning">Sửa</a>

                    <!-- Nút xóa loại đề tài -->
                    <a href="<?php echo base_url('loaidetai/delete/'.$loaidetai->maLDT); ?>" class="btn btn-danger" onclick="return confirm('Bạn có chắc chắn muốn xóa loại đề tài này?')">Xóa</a>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</body>
</html>
