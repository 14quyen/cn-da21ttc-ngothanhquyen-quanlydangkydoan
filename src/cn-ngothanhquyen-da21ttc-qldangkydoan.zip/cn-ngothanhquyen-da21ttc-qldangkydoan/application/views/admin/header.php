<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trang Quản Trị</title>
    <link rel="stylesheet" href="<?php echo base_url('assets/css/header.css'); ?>">
</head>
<body>
    <!-- Header -->
    <header class="admin-header">
        <div class="header-container">
            <!-- Logo & Tên trang -->
            <div class="header-logo">
                <img src="assets/images/logo.png" alt="Logo" class="logo">
                <span class="site-name">Trang Quản Trị</span>
            </div>

            <!-- Thanh điều hướng -->
            <nav class="header-nav">
                <ul>
                    <li><a href="taikhoan">Tài Khoản</a></li>
                    <li><a href="sinhvien">Sinh Viên</a></li>
                    <li><a href="giangvien">Giảng Viên</a></li>
                    <li><a href="detai">Đề Tài</a></li>
                    <li><a href="loaidetai">Loại Đề Tài</a></li>
                    
                    <li><a href="thongke">Thống Kê</a></li>
                </ul>
            </nav>

            <!-- Thông tin người dùng & Cài đặt -->
            <div class="user-info">
                <div class="user-name">Admin</div>
                <div class="dropdown">
                    <button class="dropdown-button">▼</button>
                    <div class="dropdown-content">
                        
                        <a href="logout">Đăng xuất</a>
                    </div>
                </div>
            </div>
        </div>
    </header>
</body>
</html>
