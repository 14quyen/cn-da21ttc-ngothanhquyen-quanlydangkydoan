<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quản lý Giảng Viên</title>
    <link rel="stylesheet" href="<?php echo base_url('assets/css/style.css'); ?>">
</head>
<body>
    <h1>Quản lý Giảng Viên</h1>
    
    <!-- Nút thêm giảng viên -->
    <a href="<?php echo base_url('taikhoan/add'); ?>" class="btn btn-primary">Thêm Giảng Viên</a>
    
    <table>
        <thead>
            <tr>
                <th>Mã Giảng Viên</th>
                <th>Tên Giảng Viên</th>
                <th>Số Điện Thoại</th>
                <th>Email</th>
                <th>Hành Động</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($giangviens as $giangvien): ?>
            <tr>
                <td><?php echo $giangvien->maGV; ?></td>
                <td><?php echo $giangvien->tenGV; ?></td>
                <td><?php echo $giangvien->sdt; ?></td>
                <td><?php echo $giangvien->email; ?></td>
                
                <td>
                    <!-- Nút sửa giảng viên -->
                    <a href="<?php echo base_url('giangvien/edit/'.$giangvien->maGV); ?>" class="btn btn-warning">Sửa</a>

                    <!-- Nút xóa giảng viên -->
                    <a href="<?php echo base_url('giangvien/delete/'.$giangvien->maGV); ?>" class="btn btn-danger" onclick="return confirm('Bạn có chắc chắn muốn xóa giảng viên này?')">Xóa</a>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</body>
</html>
