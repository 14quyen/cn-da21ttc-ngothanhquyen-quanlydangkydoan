<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quản Lý Sinh Viên</title>
    <link rel="stylesheet" href="<?php echo base_url('assets/css/style.css'); ?>">
</head>
<body>
    <h1>Quản Lý Sinh Viên</h1>
    <a href="<?php echo base_url('taikhoan/add'); ?>" class="btn btn-primary">Thêm Sinh Viên</a>

    <table>
        <thead>
            <tr>
                <th>Mã Sinh Viên</th>
                <th>Tên Sinh Viên</th>
                <th>Lớp</th>
                <th>Số Điện Thoại</th>
                <th>Email</th>
                <th>Hành Động</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($sinhviens as $sinhvien): ?>
            <tr>
                <td><?php echo $sinhvien->maSV; ?></td>
                <td><?php echo $sinhvien->tenSV; ?></td>
                <td><?php echo $sinhvien->maLop; ?></td>
                <td><?php echo $sinhvien->sdtSV; ?></td>
                <td><?php echo $sinhvien->emailSV; ?></td>
                <td>
                    <a href="<?php echo base_url('sinhvien/edit/'.$sinhvien->maSV); ?>" class="btn btn-warning">Sửa</a>
                    <a href="<?php echo base_url('sinhvien/delete/'.$sinhvien->maSV); ?>" class="btn btn-danger" onclick="return confirm('Bạn có chắc chắn muốn xóa sinh viên này?')">Xóa</a>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</body>
</html>
