<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thêm Sinh Viên</title>
    <link rel="stylesheet" href="<?php echo base_url('assets/css/add.css'); ?>">
</head>
<body>
    <h1>Thêm Sinh Viên</h1>

    <form action="<?php echo base_url('sinhvien/add_process'); ?>" method="POST">
    <input type="hidden" name="maTK" value="<?php echo $maTK; ?>">

    <label>Mã Sinh Viên:</label>
    <input type="text" name="maSV" required>

    <label>Tên Sinh Viên:</label>
    <input type="text" name="tenSV" required>

    <label>Lớp:</label>
    <input type="text" name="maLop" required>

    <label>Số Điện Thoại:</label>
    <input type="text" name="sdtSV" required>

    <label>Email:</label>
    <input type="email" name="emailSV" required>

    <button type="submit">Lưu Thông Tin</button>
</form>

</body>
</html>
