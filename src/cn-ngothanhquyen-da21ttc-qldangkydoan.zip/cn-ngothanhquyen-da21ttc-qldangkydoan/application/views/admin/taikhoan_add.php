<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thêm Tài Khoản</title>
    <link rel="stylesheet" href="<?php echo base_url('assets/css/add.css'); ?>">
</head>
<body>
    <h1>Thêm Tài Khoản</h1>
    <form action="<?php echo base_url('taikhoan/store'); ?>" method="POST">
        <label for="tenTK">Tên Tài Khoản:</label>
        <input type="text" id="tenTK" name="tenTK" required>

        <label for="matkhau">Mật Khẩu:</label>
        <input type="password" id="matkhau" name="matkhau" required>

        <label for="maQ">Quyền:</label>
        <select id="maQ" name="maQ" required>
            <option value="0">Sinh viên</option>
            <option value="1">Giảng Viên</option>
            <option value="2">Admin</option>
        </select>

        <button type="submit" class="btn btn-primary">Thêm</button>
    </form>
</body>
</html>
