<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quản lý Đề Tài</title>
    <link rel="stylesheet" href="<?php echo base_url('assets/css/style.css'); ?>">
    <link rel="stylesheet" href="<?php echo base_url('assets/css/detai.css'); ?>">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>
    <h1>Quản lý Đề Tài</h1>

    <!-- Nút thêm đề tài -->
    <a href="<?php echo base_url('detai/add'); ?>" class="btn btn-primary">Thêm Đề Tài</a>

    <!-- Bảng danh sách đề tài -->
    <table>
        <thead>
            <tr>
                <th>Mã Đề Tài</th>
                <th>Tên Đề Tài</th>
                <th>Mô Tả</th>
                
                <th>Giảng Viên</th>
                <th>Loại Đề Tài</th>
                <th>Trạng Thái Duyệt</th>
                <th>Hành Động</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($detais as $detai): ?>
            <tr>
                <td><?php echo $detai->maDT; ?></td>
                <td><?php echo $detai->tenDT; ?></td>
                <td><?php echo $detai->mota; ?></td>
                
                <td><?php echo $detai->tenGiangVien; ?></td>
                <td><?php echo $detai->tenLoaiDeTai; ?></td>
                <td>
                    <input type="checkbox" class="trangthai-checkbox" 
                        data-id="<?php echo $detai->maDT; ?>" 
                        <?php echo $detai->trangthaiDuyet == 1 ? 'checked' : ''; ?>> 
                    <span class="trangthai-label">
                        <?php echo $detai->trangthaiDuyet == 1 ? 'Đã Duyệt' : 'Chưa Duyệt'; ?>
                    </span>
                </td>

                <td>
                    <!-- Các nút hành động sửa, xóa -->
                    <a href="<?php echo base_url('detai/edit/'.$detai->maDT); ?>" class="btn btn-warning">Sửa</a>
                    <a href="<?php echo base_url('detai/delete/'.$detai->maDT); ?>" class="btn btn-danger" onclick="return confirm('Bạn có chắc chắn muốn xóa đề tài này?')">Xóa</a>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <script>
$('.trangthai-checkbox').on('change', function () {
    var maDT = $(this).data('id'); // Lấy mã đề tài từ thuộc tính data-id
    var trangthaiDuyet = $(this).is(':checked') ? 1 : 0; // Trạng thái checkbox

    // Gửi AJAX để cập nhật trạng thái duyệt
    $.ajax({
        url: '<?php echo base_url("detai/approve_ajax"); ?>', // Đường dẫn đến controller
        type: 'POST',
        data: {
            maDT: maDT,
            trangthaiDuyet: trangthaiDuyet
        },
        success: function (response) {
            // Kiểm tra phản hồi từ server
            if (response.status === 'success') {
                // Cập nhật lại trạng thái hiển thị
                var label = $('input[data-id="' + maDT + '"]').next('.trangthai-label');
                if (trangthaiDuyet == 1) {
                    label.text('Đã Duyệt');
                } else {
                    label.text('Chưa Duyệt');
                }
            } else {
                // Nếu có lỗi, hiển thị thông báo lỗi và khôi phục checkbox
                alert('Không thể cập nhật trạng thái.');
                $('input[data-id="' + maDT + '"]').prop('checked', !trangthaiDuyet); // Khôi phục trạng thái checkbox
            }
        },
        error: function () {
            alert('Có lỗi xảy ra khi cập nhật trạng thái.');
            $('input[data-id="' + maDT + '"]').prop('checked', !trangthaiDuyet); // Khôi phục trạng thái checkbox
        }
    });
});



    </script>
</body>
</html>
