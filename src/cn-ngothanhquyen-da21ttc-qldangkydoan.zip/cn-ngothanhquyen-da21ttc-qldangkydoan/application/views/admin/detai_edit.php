<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo base_url('assets/css/add.css'); ?>">
    <title>Sửa Đề Tài</title>
</head>
<body>
    <h1>Sửa Đề Tài</h1>
    <form action="<?php echo base_url('detai/update'); ?>" method="POST">
        <!-- Mã đề tài (ẩn) -->
        <input type="hidden" name="maDT" value="<?php echo $detai->maDT; ?>">

        <!-- Tên đề tài -->
        <label for="tenDT">Tên Đề Tài:</label>
        <input type="text" name="tenDT" value="<?php echo $detai->tenDT; ?>" required><br>

        <!-- Mô tả -->
        <label for="mota">Mô Tả:</label>
        <textarea name="mota" required><?php echo $detai->mota; ?></textarea><br>

        <!-- Giảng viên -->
        <label for="maGV">Giảng Viên:</label>
        <select name="maGV" required>
            <?php foreach ($giangviens as $gv): ?>
                <option value="<?php echo $gv->maGV; ?>" 
                    <?php echo ($gv->maGV == $detai->maGV) ? 'selected' : ''; ?>>
                    <?php echo $gv->tenGV; ?>
                </option>
            <?php endforeach; ?>
        </select><br>

        <!-- Loại đề tài -->
        <label for="maLDT">Loại Đề Tài:</label>
        <select name="maLDT" required>
            <?php foreach ($loaiDTs as $ldt): ?>
                <option value="<?php echo $ldt->maLDT; ?>" 
                    <?php echo ($ldt->maLDT == $detai->maLDT) ? 'selected' : ''; ?>>
                    <?php echo $ldt->tenLDT; ?>
                </option>
            <?php endforeach; ?>
        </select><br>

        <!-- Trạng thái duyệt -->
        <label for="trangthaiDuyet">Trạng Thái Duyệt:</label>
        <input type="checkbox" name="trangthaiDuyet" value="1" 
            <?php echo $detai->trangthaiDuyet ? 'checked' : ''; ?>> Đã Duyệt<br>

        <!-- Nút cập nhật -->
        <button type="submit">Cập Nhật</button>
    </form>
</body>
</html>
