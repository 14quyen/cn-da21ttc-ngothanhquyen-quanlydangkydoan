<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thêm Loại Đề Tài</title>
    <link rel="stylesheet" href="<?php echo base_url('assets/css/add.css'); ?>">
</head>
<body>
    <h1>Thêm Loại Đề Tài</h1>

    <form action="<?php echo base_url('loaidetai/add_process'); ?>" method="POST">
        <label for="maLDT">Mã Loại Đề Tài:</label>
        <input type="text" name="maLDT" id="maLDT" required>

        <label for="tenLDT">Tên Loại Đề Tài:</label>
        <input type="text" name="tenLDT" id="tenLDT" required>

        <button type="submit">Thêm Loại Đề Tài</button>
    </form>
</body>
</html>
