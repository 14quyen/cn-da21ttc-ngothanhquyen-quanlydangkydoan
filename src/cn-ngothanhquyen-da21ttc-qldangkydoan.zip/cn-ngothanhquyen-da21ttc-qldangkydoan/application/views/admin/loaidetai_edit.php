<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sửa Loại Đề Tài</title>
    <link rel="stylesheet" href="<?php echo base_url('assets/css/add.css'); ?>">
</head>
<body>
    <h1>Sửa Loại Đề Tài</h1>

    <form action="<?php echo base_url('loaidetai/edit_process'); ?>" method="POST">
        <input type="hidden" name="maLDT" value="<?php echo $loaidetai->maLDT; ?>">

        <label for="tenLDT">Tên Loại Đề Tài:</label>
        <input type="text" name="tenLDT" id="tenLDT" value="<?php echo $loaidetai->tenLDT; ?>" required>

        <button type="submit">Cập Nhật Loại Đề Tài</button>
    </form>
</body>
</html>
