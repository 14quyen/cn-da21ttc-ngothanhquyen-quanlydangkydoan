<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sửa Tài Khoản</title>
    <link rel="stylesheet" href="<?php echo base_url('assets/css/add.css'); ?>">
</head>
<body>
    <h1>Sửa Tài Khoản</h1>
    <form action="<?php echo base_url('taikhoan/update/'.$taikhoan->maTK); ?>" method="POST">
        <label for="tenTK">Tên Tài Khoản:</label>
        <input type="text" id="tenTK" name="tenTK" value="<?php echo $taikhoan->tenTK; ?>" required>

        <label for="matkhau">Mật Khẩu:</label>
        <input type="password" id="matkhau" name="matkhau" value="" placeholder="Nhập mật khẩu mới nếu thay đổi">

        <label for="maQ">Quyền:</label>
        <select id="maQ" name="maQ" required>
            <option value="0" <?php echo $taikhoan->maQ == 0 ? 'selected' : ''; ?>>Sinh viên</option>
            <option value="1" <?php echo $taikhoan->maQ == 1 ? 'selected' : ''; ?>>Giảng viên</option>
            <option value="2" <?php echo $taikhoan->maQ == 2 ? 'selected' : ''; ?>>Admin</option>
        </select>

        <button type="submit" class="btn btn-warning">Cập nhật</button>
    </form>
</body>
</html>
