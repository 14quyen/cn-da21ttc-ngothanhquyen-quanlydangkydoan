<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quản lý Tài Khoản</title>
    <link rel="stylesheet" href="<?php echo base_url('assets/css/style.css'); ?>">
</head>
<body>
    <h1>Quản lý Tài Khoản</h1>
    <a href="<?php echo base_url('taikhoan/add'); ?>" class="btn btn-primary">Thêm Tài Khoản</a>

    <table>
        <thead>
            <tr>
                <th>Mã TK</th>
                <th>Tên Tài Khoản</th>
                <th>Quyền</th>
                <th>Hành Động</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($taikhoans as $taikhoan): ?>
            <tr>
                <td><?php echo $taikhoan->maTK; ?></td>
                <td><?php echo $taikhoan->tenTK; ?></td>
                <td><?php echo $taikhoan->tenQ; ?></td>
                <td>

                    <!-- Thêm thông tin người dùng tùy theo quyền -->
                    <?php if ($taikhoan->maQ == 0): ?> <!-- Quyền sinh viên -->
                        <?php if (!$taikhoan->daThemThongTin): ?>
                            <a href="<?php echo base_url('sinhvien/add/'.$taikhoan->maTK); ?>" class="btn btn-success">Thêm Thông Tin Sinh Viên</a>
                        <?php endif; ?>
                    <?php elseif ($taikhoan->maQ == 1): ?> <!-- Quyền giảng viên -->
                        <?php if (!$taikhoan->daThemThongTin): ?>
                            <a href="<?php echo base_url('giangvien/add/'.$taikhoan->maTK); ?>" class="btn btn-success">Thêm Thông Tin Giảng Viên</a>
                    
                        <?php endif; ?>
                    <?php endif; ?>


                    <!-- Các hành động sửa, xóa -->
                    <a href="<?php echo base_url('taikhoan/edit/'.$taikhoan->maTK); ?>" class="btn btn-warning">Sửa</a>
                    <a href="<?php echo base_url('taikhoan/delete/'.$taikhoan->maTK); ?>" class="btn btn-danger" onclick="return confirm('Bạn có chắc chắn muốn xóa tài khoản này?')">Xóa</a>

                    
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</body>
</html>
