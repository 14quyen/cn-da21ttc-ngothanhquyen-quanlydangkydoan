<div class="row mt-4">
    <!-- Left side: Đề tài đã duyệt -->
    <div class="col-md-9">
        <h1>Danh Sách Đề tài</h1>
        <div class="card">
            <?php if ($this->session->flashdata('success')): ?>
                <div class="alert alert-success">
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
            <?php endif; ?>
            <?php if ($this->session->flashdata('error')): ?>
                <div class="alert alert-danger">
                    <?php echo $this->session->flashdata('error'); ?>
                </div>
            <?php endif; ?>
            <div class="card-body">
                <!-- Bảng danh sách đề tài -->
                <table class="table table-bordered mt-4">
                    <thead>
                        <tr>
                            <th>Mã đề tài</th>
                            <th>Tên đề tài</th>
                            <th>Mô tả</th>
                            <th>Loại đề tài</th>
                            <th>Giảng viên</th>
                            <th>Sinh viên đăng ký</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($approved_topics)): ?>
                            <?php foreach ($approved_topics as $topic): ?>
                                <tr>
                                    <td><?php echo $topic->maDT; ?></td>
                                    <td><?php echo $topic->tenDT; ?></td>
                                    <td><?php echo $topic->mota; ?></td>
                                    <td><?php echo $topic->tenLDT; ?></td>
                                    <td><?php echo $topic->tenGV; ?></td>
                                    <td><?php echo $topic->tenSV ? $topic->tenSV : 'Chưa có sinh viên đăng ký'; ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="6">Không có đề tài nào đã duyệt.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Right side: Thông tin cá nhân -->
    <div class="col-md-3">
        <div class="card">
            <div class="card-header bg-primary text-white">
                Thông tin cá nhân
            </div>
            <div class="card-body">
                <p><strong>Mã GV:</strong> <?php echo $giangvien->maGV; ?></p>
                <p><strong>Tên GV:</strong> <?php echo $giangvien->tenGV; ?></p>
                <p><strong>Email:</strong> <?php echo $giangvien->email; ?></p>
            </div>
        </div>
        <div class="card">
            <div class="card-header bg-primary text-white">
                Tính năng
            </div>
            <div class="card-body">
            <p><a href="<?php echo base_url('UserGV'); ?>">Trang chủ</a></p>
                <p><a href="<?php echo base_url('UserGV/danhsachGV'); ?>">DS Giảng Viên Hướng Dẫn</a></p>
                <p><a href="<?php echo base_url('UserGV/doimatkhau'); ?>">Đổi Mật Khẩu</a></p>
            </div>
        </div>
    </div>
</div>
</div>
