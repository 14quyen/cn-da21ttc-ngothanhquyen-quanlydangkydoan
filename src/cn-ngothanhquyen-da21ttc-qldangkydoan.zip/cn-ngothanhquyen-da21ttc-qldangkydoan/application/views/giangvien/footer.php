<footer class="text-center mt-4">
        <p>&copy; 2024 Quản lý Đăng ký Đồ án</p>
    </footer>
    <script src="<?php echo base_url('assets/js/bootstrap.bundle.min.js'); ?>"></script>
</body>
</html>
