<div class="row mt-4">
    <!-- Left side: Danh sách giảng viên -->

    <div class="col-md-9">
    <h1>Danh Sách Giảng viên hướng dẫn</h1>
        <div class="card">
        
            <div class="card-body">
                <table class="table table-bordered" style="text-align: center;">
                    <thead style="text-align: center;">
                        <tr >
                            <th>Mã Giảng Viên</th>
                            <th>Tên Giảng Viên</th>
                            <th>Email</th>
                            <th>Số Điện Thoại</th>
                            
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($giangvien_list)) : ?>
                            <?php foreach ($giangvien_list as $giangvien) : ?>
                                <tr>
                                    <td><?php echo $giangvien->maGV; ?></td>
                                    <td><?php echo $giangvien->tenGV; ?></td>
                                    <td><?php echo $giangvien->email; ?></td>
                                    <td><?php echo $giangvien->sdt; ?></td>
                                    
                                </tr>
                            <?php endforeach; ?>
                        <?php else : ?>
                            <tr>
                                <td colspan="5">Không có giảng viên nào.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Right side: Thông tin cá nhân -->
    <div class="col-md-3">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    Thông tin cá nhân
                </div>
                <div class="card-body">
                    <p><strong>Mã giảng viên:</strong> <?php echo $giangvien->maGV; ?></p>
                    <p><strong>Tên GV:</strong> <?php echo $giangvien->tenGV; ?></p>
                    <p><strong>Email:</strong> <?php echo $giangvien->email; ?></p>
                </div>
            </div>
            <div class="card">
                <div class="card-header bg-primary text-white">
                    Tính năng
                </div>
                <div class="card-body">
                    <p><a href="<?php echo base_url('UserGV'); ?>">Trang chủ</a></p>
                    <p><a href="<?php echo base_url('UserGV/danhsachGV'); ?>">Danh Sách Đề Tài</a></p>
                    <p><a href="<?php echo base_url('UserGV/doimatkhau'); ?>">Đổi Mật Khẩu</a></p>
                
                </div>
            </div>
        </div>
    </div>
</div>