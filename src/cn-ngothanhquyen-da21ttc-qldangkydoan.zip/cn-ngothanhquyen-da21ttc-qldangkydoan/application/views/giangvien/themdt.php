<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thêm Đề Tài</title>
    <link rel="stylesheet" href="<?php echo base_url('assets/css/add.css'); ?>">
</head>
<body>
    <h2>Thêm Đề Tài</h2>

    <!-- Hiển thị thông báo -->
    <?php if ($this->session->flashdata('success')): ?>
        <div class="alert alert-success">
            <?php echo $this->session->flashdata('success'); ?>
        </div>
    <?php endif; ?>
    <?php if ($this->session->flashdata('error')): ?>
        <div class="alert alert-danger">
            <?php echo $this->session->flashdata('error'); ?>
        </div>
    <?php endif; ?>

    <form method="post" action="<?php echo base_url('UserGV/them_detai'); ?>">
        <div class="form-group">
            <label for="tenDT">Tên Đề Tài</label>
            <input type="text" class="form-control" id="tenDT" name="tenDT" required>
        </div>

        <div class="form-group">
            <label for="mota">Mô Tả</label>
            <textarea class="form-control" id="mota" name="mota" rows="4" required></textarea>
        </div>

        <div class="form-group">
            <label for="maLDT">Loại Đề Tài</label>
            <select class="form-control" id="maLDT" name="maLDT" required>
                <option value="">Chọn Loại Đề Tài</option>
                <?php foreach ($loaiDT as $ldt): ?>
                    <option value="<?php echo $ldt->maLDT; ?>"><?php echo $ldt->tenLDT; ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <button type="submit" class="btn btn-primary">Thêm Đề Tài</button>
        
        <a href="<?php echo base_url('UserGV'); ?>" class="btn btn-primary2">Quay Lại</a>
    </form>
    </body>
    </html>
