<div class="row mt-4">
        <!-- Left side: Đề tài đăng ký -->
        <div class="col-md-9">
        <h1>Đề tài đã duyệt</h1>
            <div class="card" >
                
                <?php if ($this->session->flashdata('success')): ?>
        <div class="alert alert-success">
            <?php echo $this->session->flashdata('success'); ?>
        </div>
    <?php endif; ?>
    <?php if ($this->session->flashdata('error')): ?>
        <div class="alert alert-danger">
            <?php echo $this->session->flashdata('error'); ?>
        </div>
    <?php endif; ?>
    <div class="card-body">
    <!-- Bảng danh sách đề tài -->
    <table class="table table-bordered mt-4">
    
        <thead>
            <tr>
                <th>Mã đề tài</th>
                <th>Tên đề tài</th>
                <th>Mô tả</th>
                <th>Loại đề tài</th>
                <th>Sinh viên đăng ký</th>
            </tr>
        </thead>
        <tbody>
            <?php if (!empty($approved_topics)): ?>
                <?php foreach ($approved_topics as $topic): ?>
                    <tr>
                        <td><?php echo $topic->maDT; ?></td>
                        <td><?php echo $topic->tenDT; ?></td>
                        <td><?php echo $topic->mota; ?></td>
                        <td><?php echo $topic->tenLDT; ?></td>
                        <td><?php echo $topic->tenSV ? $topic->tenSV : 'Chưa có sinh viên đăng ký'; ?></td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="5">Không có đề tài nào đã duyệt.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
     </div>

     <h1>Đề tài chưa duyệt</h1>
     <a href="<?php echo base_url('userGV/them_detai'); ?>" class="btn btn-primary">Thêm Đề Tài</a>
            <div class="card" >
    <div class="card-body">
    <!-- Bảng danh sách đề tài -->
    <table class="table table-bordered mt-4">
    
    <thead>
            <tr>
                <th>Mã đề tài</th>
                <th>Tên đề tài</th>
                <th>Mô tả</th>
                <th>Loại đề tài</th>
                <th>Hành động</th>
            </tr>
        </thead>
        <tbody>
            <?php if (!empty($detaichuaduyet)): ?>
                <?php foreach ($detaichuaduyet as $detai): ?>
                    <tr>
                        <td><?= $detai->maDT ?></td>
                        <td><?= $detai->tenDT ?></td>
                        <td><?= $detai->mota ?></td>
                        <td><?= $detai->tenLDT ?></td>
                        <td>
                    <!-- Nút sửa loại đề tài -->
                    <a href="<?php echo base_url('UserGV/sua_detai/'.$detai->maDT); ?>" class="btn btn-warning" style="text-decoration: none; "><i class='far fa-edit'></i></a>

                    <!-- Nút xóa loại đề tài -->
                    <a href="<?php echo base_url('UserGV/delete/'.$detai->maDT); ?>" class="btn btn-danger" style="text-decoration: none;" onclick="return confirm('Bạn có chắc chắn muốn xóa loại đề tài này?')"><i class="fas fa-trash-alt"></i></a>
                </td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="4">Không có đề tài nào chưa duyệt.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
     </div>
</div>
        

        <!-- Right side: Thông tin cá nhân -->
        <div class="col-md-3">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    Thông tin cá nhân
                </div>
                <div class="card-body">
                    <p><strong>Mã GV:</strong> <?php echo $giangvien->maGV; ?></p>
                    <p><strong>Tên GV:</strong> <?php echo $giangvien->tenGV; ?></p>
                    <p><strong>Email:</strong> <?php echo $giangvien->email; ?></p>
                </div>
            </div>
            <div class="card">
                <div class="card-header bg-primary text-white">
                    Tính năng
                </div>
                <div class="card-body" >
                    <p><a href="<?php echo base_url('UserGV/danhsach_detai'); ?>">Danh Sách Đề Tài</a></p>
                    <p><a href="<?php echo base_url('UserGV/danhsachGV'); ?>">DS Giảng Viên Hướng Dẫn</a></p>
                    <p><a href="<?php echo base_url('UserGV/doimatkhau'); ?>">Đổi Mật Khẩu</a></p>
                
                </div>
            </div>
        </div>
    </div>
</div>