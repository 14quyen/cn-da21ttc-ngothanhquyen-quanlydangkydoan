<div class="row mt-4">
        <!-- Left side: Đề tài đăng ký -->
        <div class="col-md-9">
            <div class="card" style="min-height: 500px;">
                <div class="card-header bg-info text-white">
                    Đề tài đã đăng ký
                </div>
                <?php if ($this->session->flashdata('success')): ?>
    <p class="text-success"><?php echo $this->session->flashdata('success'); ?></p>
<?php endif; ?>
<?php if ($this->session->flashdata('error')): ?>
    <p class="text-danger"><?php echo $this->session->flashdata('error'); ?></p>
<?php endif; ?>

                <div class="card-body">
                    <table class="table table-bordered">
                        
                        <thead style="text-align: center;">
                            <tr>
                                <th>Tên đề tài</th>
                                <th>Giảng viên hướng dẫn</th>
                                <th>Trạng thái</th>
                                <th>Hành động</th>
                            </tr>
                        <tbody>
                            <?php if (!empty($detai_dadangky)) : ?>
                                <?php foreach ($detai_dadangky as $detai) : ?>
                                    <tr>
                                        <td><?php echo isset($detai->tenDT) ? $detai->tenDT : 'Chưa có'; ?></td>
                                        <td style="text-align: center;"><?php echo isset($detai->giangvien) ? $detai->giangvien : 'Chưa có'; ?></td>
                                        <td style="text-align: center;"><?php echo isset($detai->trangthaiDK) ? $detai->trangthaiDK : 'Chưa cập nhật'; ?></td>
                                        <td style="text-align: center;">
                                            <form action="<?php echo base_url('UserSV/huyDangkyDetai'); ?>" method="post">
                                                <input type="hidden" name="maDT" value="<?php echo $detai->maDT; ?>">
                                                <button type="submit" class="btn btn-danger">Hủy đăng ký</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else : ?>
                                <tr>
                                    <td colspan="4">Bạn chưa đăng ký đề tài nào.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Right side: Thông tin cá nhân -->
        <div class="col-md-3">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    Thông tin cá nhân
                </div>
                <div class="card-body">
                    <p><strong>Mã sinh viên:</strong> <?php echo $sinhvien->maSV; ?></p>
                    <p><strong>Lớp:</strong> <?php echo $sinhvien->maLop; ?></p>
                    <p><strong>Email:</strong> <?php echo $sinhvien->emailSV; ?></p>
                </div>
            </div>
            <div class="card">
                <div class="card-header bg-primary text-white">
                    Tính năng
                </div>
                <div class="card-body">
                    <p><a href="<?php echo base_url('UserSV/dangkyDetai'); ?>">Đăng Ký Đề Tài</a></p>
                    <p><a href="<?php echo base_url('UserSV/danhsachGV'); ?>">DS Giảng Viên Hướng Dẫn</a></p>
                    <p><a href="<?php echo base_url('UserSV/doimatkhau'); ?>">Đổi Mật Khẩu</a></p>
                
                </div>
            </div>
        </div>
    </div>
</div>