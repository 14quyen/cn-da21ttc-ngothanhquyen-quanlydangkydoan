<div class="row mt-4">
        <!-- Left side: Đề tài đăng ký -->
        <div class="col-md-9">


<div class="card">
    <div class="card-header bg-info text-white">
        Đăng ký đề tài
    </div>
    <div class="card-body">
        <!-- Thông báo thành công hoặc lỗi -->
        <?php if ($this->session->flashdata('success')): ?>
            <p class="text-success"><?php echo $this->session->flashdata('success'); ?></p>
        <?php endif; ?>
        <?php if ($this->session->flashdata('error')): ?>
            <p class="text-danger"><?php echo $this->session->flashdata('error'); ?></p>
        <?php endif; ?>

        <!-- Lọc theo loại đề tài -->
        <form action="" method="get">
    <div class="form-group">
        <label for="maLDT">Chọn loại đề tài</label>
        <select class="form-control" name="maLDT" id="maLDT">
            <option value="">Tất cả</option>
            <?php foreach ($loaiDT as $loai): ?>
                <option value="<?php echo $loai->maLDT; ?>" <?php echo isset($_GET['maLDT']) && $_GET['maLDT'] == $loai->maLDT ? 'selected' : ''; ?>>
                    <?php echo $loai->tenLDT; ?>
                </option>
            <?php endforeach; ?>
        </select>
    </div>
    <button type="submit" class="btn btn-primary" >Lọc</button>
</form>


        <!-- Hiển thị danh sách đề tài -->
        <table class="table table-bordered">
    <thead>
        <tr style="text-align: center;">
            <th style="width: 80px;">Mã đề tài</th>
            <th style="width: 300px;">Tên đề tài</th>
            <th>Mô tả</th>
            <th style="width: 200px;">Giảng viên hướng dẫn</th>
            <th style="width: 100px;">Đăng ký</th>
        </tr>
    </thead>
    <tbody>
        <?php if (!empty($detai_chuadk)): ?>
            <?php foreach ($detai_chuadk as $detai): ?>
                <tr>
                    <td style="text-align: center;"><?php echo $detai->maDT; ?></td>
                    <td><?php echo $detai->tenDT; ?></td>
                    <td><?php echo $detai->mota; ?></td>
                    <td style="text-align: center;"><?php echo $detai->tenGV; ?></td>
                    <td>
                        <form action="<?php echo base_url('UserSV/xulyDangkyDetai'); ?>" method="post">
                            <input type="hidden" name="maDT" value="<?php echo $detai->maDT; ?>">
                            <button type="submit" class="btn btn-primary">Đăng ký</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
        <?php else: ?>
            <tr>
                <td colspan="5" class="text-center">Không có đề tài nào khả dụng.</td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>

    </div>
</div>
</div>
        <!-- Right side: Thông tin cá nhân -->
        <div class="col-md-3">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    Thông tin cá nhân
                </div>
                <div class="card-body">
                    <p><strong>Mã sinh viên:</strong> <?php echo $sinhvien->maSV; ?></p>
                    <p><strong>Lớp:</strong> <?php echo $sinhvien->maLop; ?></p>
                    <p><strong>Email:</strong> <?php echo $sinhvien->emailSV; ?></p>
                </div>
            </div>
            <div class="card">
                <div class="card-header bg-primary text-white">
                    Tính năng
                </div>
                <div class="card-body">
                <p><a href="<?php echo base_url('UserSV'); ?>">Trang Chủ</a></p>
                    <p><a href="<?php echo base_url('UserSV/danhsachGV'); ?>">DS Giảng Viên Hướng Dẫn</a></p>
                    <p><a href="<?php echo base_url('UserSV/doimatkhau'); ?>">Đổi Mật Khẩu</a></p>
                
                </div>
            </div>
        </div>
    </div>
</div>