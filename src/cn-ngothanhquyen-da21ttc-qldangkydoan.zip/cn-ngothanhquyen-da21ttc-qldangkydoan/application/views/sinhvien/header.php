<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trang chủ - Sinh viên</title>
    <link rel="stylesheet" href="<?php echo base_url('assets/css/bootstrap.min.css'); ?>">
    <link rel="stylesheet" href="<?php echo base_url('assets/css/sinhvien.css'); ?>">
</head>
<body>
<div class="container">
    <div class="row mt-4">
        <!-- Menu bar -->
        <div class="col-12">
            <nav class="navbar navbar-expand-lg navbar-light bg-light">
                <a class="navbar-brand" href="#">Trang chủ</a>
                
                <div class="collapse navbar-collapse justify-content-center">
                    <span class="navbar-text">
                        Chào mừng, <?php echo $sinhvien->tenSV; ?>!
                    </span>
                </div>
                <a class="btn btn-secondary ml-auto" href="<?php echo base_url('logout'); ?>" role="button">
                    Đăng xuất
                </a>
            </nav>
        </div>
    </div>
