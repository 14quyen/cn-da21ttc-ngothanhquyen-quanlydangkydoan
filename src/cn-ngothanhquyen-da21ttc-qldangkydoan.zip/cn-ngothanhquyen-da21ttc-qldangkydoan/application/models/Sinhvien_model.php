<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Sinhvien_model extends CI_Model {
    public function __construct()
    {
        parent::__construct();
        $this->load->database(); // Khởi tạo kết nối cơ sở dữ liệu
        
    }

    
    // Lấy tất cả sinh viên
    public function get_all_sinhviens() {
        return $this->db->get('sinhvien')->result();
    }
    public function check_exists($maTK) {
        $this->db->where('maTK', $maTK);
        $query = $this->db->get('sinhvien');
        return $query->num_rows() > 0;
    }

    public function insert($data) {
        $this->db->insert('sinhvien', $data);
    }


    // Lấy thông tin sinh viên theo mã
    public function get_sinhvien_by_id($maSV) {
        return $this->db->get_where('sinhvien', array('maSV' => $maSV))->row();
    }

    // Cập nhật thông tin sinh viên
    public function update_sinhvien($maSV, $data) {
        $this->db->where('maSV', $maSV);
        $this->db->update('sinhvien', $data);
    }

    // Xóa sinh viên
    public function delete_sinhvien($maSV) {
        $this->db->delete('sinhvien', array('maSV' => $maSV));
    }
}
