<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Giangvien_model extends CI_Model {
    public function __construct()
    {
        parent::__construct();
        $this->load->database(); // Khởi tạo kết nối cơ sở dữ liệu
        
    }
    // Lấy tất cả giảng viên
    public function get_all() {
        $query = $this->db->get('giangvien');
        return $query->result();
    }

    // Lấy giảng viên theo mã giảng viên
    public function get_by_id($maGV) {
        $query = $this->db->get_where('giangvien', array('maGV' => $maGV));
        return $query->row();
    }
    public function check_exists($maTK) {
        $this->db->where('maTK', $maTK);
        $query = $this->db->get('giangvien');
        return $query->num_rows() > 0;
    }


    // Thêm giảng viên
    public function insert($data) {
        $this->db->insert('giangvien', $data);
    }

    // Cập nhật giảng viên
    public function update($maGV, $data) {
        $this->db->where('maGV', $maGV);
        $this->db->update('giangvien', $data);
    }

    // Xóa giảng viên
    public function delete($maGV) {
        $this->db->delete('giangvien', array('maGV' => $maGV));
    }



    public function get_giangvien_by_tenTK($tenTK) {
        $this->db->select('giangvien.*');
        $this->db->from('giangvien');
        $this->db->join('taikhoan', 'giangvien.maTK = taikhoan.maTK', 'inner');
        $this->db->where('taikhoan.tenTK', $tenTK);

        $query = $this->db->get();
        return $query->row(); // Trả về một đối tượng chứa thông tin giảng viên
    }
}
