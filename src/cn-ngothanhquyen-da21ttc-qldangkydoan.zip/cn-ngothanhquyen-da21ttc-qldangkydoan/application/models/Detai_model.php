<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Detai_model extends CI_Model {
 public function __construct()
    {
        parent::__construct();
        $this->load->database(); // Khởi tạo kết nối cơ sở dữ liệu
        
    }
    // Lấy tất cả đề tài
    public function get_all() {
        $this->db->select('detai.maDT, detai.tenDT, detai.mota, detai.trangthaiDuyet, 
        giangvien.tenGV AS tenGiangVien, loaiDT.tenLDT AS tenLoaiDeTai');
        $this->db->from('detai');
        $this->db->join('giangvien', 'giangvien.maGV = detai.maGV', 'left'); // Join bảng giảng viên
        $this->db->join('loaiDT', 'loaiDT.maLDT = detai.maLDT', 'left');     // Join bảng loại đề tài
        $query = $this->db->get();
        return $query->result();
    }

    // Lấy đề tài theo mã
    public function get_by_id($maDT) {
        $query = $this->db->get_where('detai', array('maDT' => $maDT));
        return $query->row();
    }

    // Thêm đề tài mới
    public function insert($data) {
        $this->db->insert('detai', $data);
    }

    public function checkTopicExists($maDT) {
        $this->db->select('maDT');
        $this->db->from('detai');
        $this->db->where('maDT', $maDT);
        $query = $this->db->get();
        return $query->num_rows() > 0; // Trả về true nếu tồn tại, false nếu không
    }
    
    public function updateDetai($maDT, $data) {
        log_message('error', 'Cập nhật trạng thái cho maDT: ' . $maDT . ' với dữ liệu: ' . json_encode($data));
        $this->db->where('maDT', $maDT);
        $result = $this->db->update('detai', $data); // Trả về true/false tùy vào việc cập nhật thành công hay không
        if ($result) {
            log_message('error', 'Cập nhật thành công cho maDT: ' . $maDT);
        } else {
            log_message('error', 'Cập nhật thất bại cho maDT: ' . $maDT);
        }
        return $result;
    }
    
    

    // Xóa đề tài
    public function delete($maDT) {
        $this->db->delete('detai', array('maDT' => $maDT));
    }


    public function get_all_loaiDT() {
        // Truy vấn lấy tất cả các loại đề tài
        $query = $this->db->get('loaiDT');
        return $query->result();
    }
    
    public function get_detai_by_loai($maLDT) {
        // Truy vấn lấy danh sách đề tài theo mã loại đề tài
        $this->db->where('maLDT', $maLDT);
        $query = $this->db->get('detai');
        return $query->result();
    }
    
    public function get_giangvien_by_id($maGV) {
        // Truy vấn lấy thông tin giảng viên theo mã giảng viên
        $this->db->where('maGV', $maGV);
        $query = $this->db->get('giangvien');
        return $query->row();
    }
    
    public function get_sinhvien_by_detai($maDT) {
        // Truy vấn lấy danh sách sinh viên đăng ký đề tài
        $this->db->select('sinhvien.tenSV');
        $this->db->from('dangky');
        $this->db->join('sinhvien', 'sinhvien.maSV = dangky.maSV');
        $this->db->where('dangky.maDT', $maDT);
        $query = $this->db->get();
        return $query->result();
    }
    

    ///////////////////////////////////////////



    public function get_approved_topics_by_giangvien($maGV) {
        $this->db->select('
            detai.maDT,
            detai.tenDT,
            detai.mota,
            loaiDT.tenLDT,   
            sinhvien.tenSV  
        ');
        $this->db->from('detai');
        $this->db->join('loaiDT', 'loaiDT.maLDT = detai.maLDT', 'inner'); // Join với bảng loại đề tài
        $this->db->join('dangky', 'dangky.maDT = detai.maDT', 'left');    // Join với bảng đăng ký
        $this->db->join('sinhvien', 'sinhvien.maSV = dangky.maSV', 'left'); // Join với bảng sinh viên
        $this->db->where('detai.trangthaiDuyet', '1'); // Chỉ lấy đề tài đã duyệt
        $this->db->where('detai.maGV', $maGV); // Chỉ lấy đề tài của giảng viên hiện tại
    
        $query = $this->db->get();
    
        // Trả về kết quả
        if ($query->num_rows() > 0) {
            return $query->result();
        } else {
            return [];
        }
    }
    ///////////////////////////////////////////////////////////
    public function get_detai_chuaduyet_by_tenTK($maGV) {
        $this->db->select('
            detai.maDT,
            detai.tenDT,
            detai.mota,
            loaiDT.tenLDT,   
            
        ');
        $this->db->from('detai');
        $this->db->join('loaiDT', 'loaiDT.maLDT = detai.maLDT', 'inner'); // Join với bảng loại đề tài
        $this->db->join('dangky', 'dangky.maDT = detai.maDT', 'left');    // Join với bảng đăng ký
        
        $this->db->where('detai.trangthaiDuyet', '0'); // Chỉ lấy đề tài đã duyệt
        $this->db->where('detai.maGV', $maGV); // Chỉ lấy đề tài của giảng viên hiện tại
    
        $query = $this->db->get();
    
        // Trả về kết quả
        if ($query->num_rows() > 0) {
            return $query->result();
        } else {
            return [];
        }
    }

}
