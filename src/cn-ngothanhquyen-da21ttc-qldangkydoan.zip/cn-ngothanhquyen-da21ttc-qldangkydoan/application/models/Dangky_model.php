<?php
class Dangky_model extends CI_Model {
    public function __construct()
    {
        parent::__construct();
        $this->load->database(); // Khởi tạo kết nối cơ sở dữ liệu
    }
    // Lấy danh sách đề tài đã đăng ký của sinh viên
    public function get_by_sinhvien($maSV) {
        $this->db->select('dangky.*, detai.tenDT, giangvien.tenGV AS giangvien, dangky.trangthaiDK'); // Chọn các trường cần lấy
        $this->db->from('dangky');
        $this->db->join('detai', 'dangky.maDT = detai.maDT', 'left'); // Join với bảng detai
        $this->db->join('giangvien', 'detai.maGV = giangvien.maGV', 'left'); // Join với bảng giảng viên
        $this->db->where('dangky.maSV', $maSV); // Điều kiện lấy theo maSV
        $query = $this->db->get();
    
        return $query->result(); // Trả về danh sách kết quả
    }

    ////////////////////////////////////
    public function dangky_detai($maSV, $maDT) {
        // Kiểm tra sinh viên đã đăng ký đề tài hay chưa
        $query = $this->db->get_where('dangky', ['maSV' => $maSV]);
        if ($query->num_rows() > 0) {
            return false; // Đã đăng ký trước đó
        }
    
        // Thêm bản ghi đăng ký
        $data = [
            'maSV' => $maSV,
            'maDT' => $maDT,
            'trangthaiDK' => 'Da_Dang_Ky'
        ];
    
        return $this->db->insert('dangky', $data);
    }
    public function huy_dangky($maSV, $maDT) {
        $this->db->where('maSV', $maSV);
        $this->db->where('maDT', $maDT);
        return $this->db->delete('dangky');
    }
    
}
