<?php
class UserSV_model extends CI_Model {
    public function __construct()
    {
        parent::__construct();
        $this->load->database(); // Khởi tạo kết nối cơ sở dữ liệu
    }
    // Lấy thông tin sinh viên dựa theo mã tài khoản
    public function get_by_tenTK($tenTK) {
        // Truy vấn thông tin sinh viên dựa trên `tenTK`
        $this->db->select('sinhvien.*'); // Lấy dữ liệu từ bảng sinhvien
        $this->db->from('sinhvien');
        $this->db->join('taikhoan', 'taikhoan.maTK = sinhvien.maTK'); // Kết nối bảng sinhvien với taikhoan
        $this->db->where('taikhoan.tenTK', $tenTK); // Điều kiện tìm kiếm
        $query = $this->db->get();

        // Trả về kết quả nếu tìm thấy, ngược lại trả null
        if ($query->num_rows() > 0) {
            return $query->row(); // Trả về một dòng dưới dạng object
        }
        return null;
    }
    public function get_by_TK($tenTK) {
        $this->db->where('tenTK', $tenTK);
        $query = $this->db->get('taikhoan');
    
        if ($query->num_rows() > 0) {
            return $query->row(); // Trả về một dòng dữ liệu
        }
    
        return null; // Không tìm thấy
    }
    
    public function update_password($tenTK, $new_password) {
        $this->db->set('matkhau', $new_password);
        $this->db->where('tenTK', $tenTK);
        $this->db->update('taikhoan'); 
    }
    

    public function get_all_giangvien() {
        // Truy vấn danh sách giảng viên từ bảng giangvien
        $this->db->select('maGV, tenGV, email, sdt');
        $this->db->from('giangvien'); // Giả sử bảng giảng viên tên là 'giangvien'
        $query = $this->db->get();
    
        // Trả về kết quả dưới dạng mảng đối tượng
        return $query->result();
    }
    
    //////////////////////////////
    public function get_detai_chuadk_by_loaiDT($maLDT) {
        // Chọn các trường cần thiết từ bảng detai và giangvien
        $this->db->select('detai.maDT, detai.tenDT, detai.mota, giangvien.tenGV, loaiDT.tenLDT');
        
        // Kết nối bảng detai với bảng giangvien và bảng loaiDT
        $this->db->from('detai');
        $this->db->join('giangvien', 'detai.maGV = giangvien.maGV', 'left'); // Kết nối giảng viên
        $this->db->join('loaiDT', 'detai.maLDT = loaiDT.maLDT', 'left'); // Kết nối loại đề tài
        
        // Lọc theo trạng thái duyệt và loại đề tài
        $this->db->where('detai.trangthaiDuyet', '1');  // Lọc đề tài đã duyệt
        $this->db->where('detai.maLDT', $maLDT);  // Lọc theo mã loại đề tài
    
        // Lọc các đề tài chưa có sinh viên đăng ký
        $this->db->where('detai.maDT NOT IN (SELECT maDT FROM dangky WHERE trangthaiDK = "Da_Dang_Ky")', null, false);
        
        // Thực hiện truy vấn
        $query = $this->db->get();
        
        return $query->result();  // Trả về kết quả là danh sách đề tài chưa có sinh viên đăng ký
    }
    
    public function get_all_loaiDT() {
        $query = $this->db->get('loaiDT');  // Lấy tất cả các loại đề tài từ bảng loaiDT
        return $query->result();  // Trả về kết quả dưới dạng mảng đối tượng
    }
    
    public function get_detai_chuadk($loaiDT_selected = null) {
        $this->db->select('detai.maDT, detai.tenDT, detai.mota, giangvien.tenGV');
        $this->db->from('detai');
        $this->db->join('giangvien', 'detai.maGV = giangvien.maGV', 'left');
        $this->db->where('detai.trangthaiDuyet', '1');
    
        // Nếu có loại đề tài được chọn, thêm điều kiện vào query
        if ($loaiDT_selected) {
            $this->db->where('detai.maLDT', $loaiDT_selected);
        }
    
        // Truy vấn các đề tài chưa đăng ký
        $this->db->where('detai.maDT NOT IN (SELECT maDT FROM dangky WHERE trangthaiDK = "Da_Dang_Ky")', null, false);
    
        $query = $this->db->get();
        return $query->result();
    }
}
