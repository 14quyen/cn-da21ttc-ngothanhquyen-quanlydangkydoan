<?php
class UserGV_model extends CI_Model {
    public function __construct()
    {
        parent::__construct();
        $this->load->database(); // Khởi tạo kết nối cơ sở dữ liệu
    }
    // Lấy thông tin sinh viên dựa theo mã tài khoản
    public function get_by_tenTK($tenTK) {
        // Truy vấn thông tin sinh viên dựa trên `tenTK`
        $this->db->select('giangvien.*'); // Lấy dữ liệu từ bảng sinhvien
        $this->db->from('giangvien');
        $this->db->join('taikhoan', 'taikhoan.maTK = giangvien.maTK'); // Kết nối bảng sinhvien với taikhoan
        $this->db->where('taikhoan.tenTK', $tenTK); // Điều kiện tìm kiếm
        $query = $this->db->get();

        // Trả về kết quả nếu tìm thấy, ngược lại trả null
        if ($query->num_rows() > 0) {
            return $query->row(); // Trả về một dòng dưới dạng object
        }
        return null;
    }
    public function get_by_TK($tenTK) {
        $this->db->where('tenTK', $tenTK);
        $query = $this->db->get('taikhoan');
    
        if ($query->num_rows() > 0) {
            return $query->row(); // Trả về một dòng dữ liệu
        }
    
        return null; // Không tìm thấy
    }
    
    public function update_password($tenTK, $new_password) {
        $this->db->set('matkhau', $new_password);
        $this->db->where('tenTK', $tenTK);
        $this->db->update('taikhoan'); 
    }
    

    public function get_all_giangvien() {
        // Truy vấn danh sách giảng viên từ bảng giangvien
        $this->db->select('giangvien.*');
        $this->db->from('giangvien'); // Giả sử bảng giảng viên tên là 'giangvien'
        $query = $this->db->get();
    
        // Trả về kết quả dưới dạng mảng đối tượng
        return $query->result();
    }
    
    //////////////////////////////////////////////////////



    public function get_approved_topics() {
        $this->db->select('
            detai.maDT,
            detai.tenDT,
            detai.mota,
            giangvien.tenGV,
            loaiDT.tenLDT,   
            sinhvien.tenSV  
        ');
        $this->db->from('detai');
        $this->db->join('loaiDT', 'loaiDT.maLDT = detai.maLDT', 'inner'); // Join với bảng loại đề tài
        $this->db->join('dangky', 'dangky.maDT = detai.maDT', 'left');    // Join với bảng đăng ký
        $this->db->join('giangvien', 'detai.maGV = giangvien.maGV');
        $this->db->join('sinhvien', 'sinhvien.maSV = dangky.maSV', 'left'); // Join với bảng sinh viên
        $this->db->where('detai.trangthaiDuyet', '1'); // Chỉ lấy đề tài đã duyệt
        
    
        $query = $this->db->get();
    
        // Trả về kết quả
        if ($query->num_rows() > 0) {
            return $query->result();
        } else {
            return [];
        }
    }


public function deleteDetai($maDT) {
    return $this->db->delete('detai', ['maDT' => $maDT]); // Xóa đề tài
}
}
