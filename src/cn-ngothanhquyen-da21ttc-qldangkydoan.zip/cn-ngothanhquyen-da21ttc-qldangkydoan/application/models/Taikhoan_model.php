<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Taikhoan_model extends CI_Model {
    public function __construct()
    {
        parent::__construct();
        $this->load->database(); // Khởi tạo kết nối cơ sở dữ liệu
    }
    // Lấy tất cả tài khoản
    public function get_all_taikhoans() {
        $query = $this->db->get('taikhoan');
        return $query->result();
    }

    // Lấy tài khoản theo mã
    public function get_taikhoan_by_id($maTK) {
        $query = $this->db->get_where('taikhoan', array('maTK' => $maTK));
        return $query->row();
    }

    // Thêm tài khoản
    public function insert_taikhoan($data) {
        $this->db->insert('taikhoan', $data);
    }

    // Cập nhật tài khoản
    public function update_taikhoan($maTK, $data) {
        $this->db->where('maTK', $maTK);
        $this->db->update('taikhoan', $data);
    }

    // Xóa tài khoản
    public function delete_taikhoan($maTK) {
        $this->db->delete('taikhoan', array('maTK' => $maTK));
    }

    public function get_taikhoans_with_roles()
    {
        $this->db->select('taikhoan.*, quyen.tenQ');
        $this->db->from('taikhoan');
        $this->db->join('quyen', 'taikhoan.maQ = quyen.maQ', 'left'); // Thực hiện LEFT JOIN để lấy tên quyền
        $query = $this->db->get();
        return $query->result();
    }
}
