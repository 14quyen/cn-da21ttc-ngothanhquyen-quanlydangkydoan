<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class LoginModel extends CI_Model
{
    public function __construct()
    {
        parent::__construct();
        $this->load->database(); // Khởi tạo kết nối cơ sở dữ liệu
    }
    public function get_user_by_username($tenTK) {
        $this->db->where('tenTK', $tenTK);
        $query = $this->db->get('taikhoan');
        return $query->row(); // Trả về 1 dòng dữ liệu
    }
}
