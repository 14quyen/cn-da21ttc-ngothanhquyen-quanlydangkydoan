<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Loaidetai_model extends CI_Model {
    public function __construct()
    {
        parent::__construct();
        $this->load->database(); // Khởi tạo kết nối cơ sở dữ liệu
        
    }
    // Lấy tất cả loại đề tài
    public function get_all() {
        $query = $this->db->get('loaidt');
        return $query->result();
    }

    // Lấy loại đề tài theo mã
    public function get_by_id($maLDT) {
        $query = $this->db->get_where('loaidt', array('maLDT' => $maLDT));
        return $query->row();
    }

    // Thêm loại đề tài
    public function insert($data) {
        $this->db->insert('loaidt', $data);
    }

    // Cập nhật loại đề tài
    public function update($maLDT, $data) {
        $this->db->where('maLDT', $maLDT);
        $this->db->update('loaidt', $data);
    }

    // Xóa loại đề tài
    public function delete($maLDT) {
        $this->db->delete('loaidt', array('maLDT' => $maLDT));
    }
}
