<?php
defined('BASEPATH') OR exit('No direct script access allowed');



$route['default_controller'] = 'login';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;




$route['taikhoan'] = 'taikhoan/index';
$route['sinhvien'] = 'sinhvien/index';
$route['giangvien'] = 'giangvien/index';
$route['detai'] = 'detai/index';
$route['loaidetai'] = 'loaidetai/index';
$route['thongke'] = 'detai/thong_ke';
$route['UserSV'] = 'UserSV/index';
$route['UserGV'] = 'UserGV/home';



$route['login'] = 'login/index';
$route['login/login_process'] = 'login/login_process';
$route['logout'] = 'login/logout';
