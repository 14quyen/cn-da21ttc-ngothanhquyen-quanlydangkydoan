<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class userSV extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->helper('url');
        $this->load->model('UserSV_model');
        $this->load->model('Dangky_model');
        
    }

    public function index() {
        // Lấy tên tài khoản từ session
        $tenTK = $this->session->userdata('tenTK');

        if (!$tenTK) {
            show_error('Bạn chưa đăng nhập.', 403);
            return;
        }

       
        $sinhvien = $this->UserSV_model->get_by_tenTK($tenTK);

        // Kiểm tra kết quả
        if (!$sinhvien) {
            show_error('Không tìm thấy thông tin sinh viên.', 404);
            return;
        }
        $data['sinhvien'] = $sinhvien; // Lưu sinh viên vào mảng dữ liệu
        $data['detai_dadangky'] = $this->Dangky_model->get_by_sinhvien($sinhvien->maSV);
        // Truyền dữ liệu cho view
        $data['sinhvien'] = $sinhvien;
        $this->load->view('sinhvien/header', $data);
        $this->load->view('sinhvien/home', $data);
        $this->load->view('sinhvien/footer', $data);
    }

    public function doimatkhau() {
        $tenTK = $this->session->userdata('tenTK');
    
        if (!$tenTK) {
            redirect('login');
            return;
        }
    
        $old_password = $this->input->post('old_password');
        $new_password = $this->input->post('new_password');
        $confirm_password = $this->input->post('confirm_password');
    
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // Kiểm tra dữ liệu nhập
            if (empty($old_password) || empty($new_password) || empty($confirm_password)) {
                $this->session->set_flashdata('error', 'Vui lòng nhập đầy đủ thông tin.');
                redirect('UserSV/doimatkhau');
                return;
            }
    
            if ($new_password !== $confirm_password) {
                $this->session->set_flashdata('error', 'Mật khẩu mới và xác nhận mật khẩu không khớp.');
                redirect('UserSV/doimatkhau');
                return;
            }
    
            $sinhvien = $this->UserSV_model->get_by_TK($tenTK);
    
            if (!$sinhvien || !password_verify($old_password, $sinhvien->matkhau)) {
                $this->session->set_flashdata('error', 'Mật khẩu hiện tại không đúng.');
                redirect('UserSV/doimatkhau');
                return;
            }
            if (password_verify($new_password, $sinhvien->matkhau)) {
                $this->session->set_flashdata('error', 'Mật khẩu mới không được trùng với mật khẩu hiện tại.');
                redirect('UserSV/doimatkhau');
                return;
            }
            // Cập nhật mật khẩu
            $hashed_password = password_hash($new_password, PASSWORD_BCRYPT);
            $this->UserSV_model->update_password($tenTK, $hashed_password);
    
            $this->session->set_flashdata('success', 'Đổi mật khẩu thành công.');
            redirect('UserSV/index');
            return;
        }
    
        // Load view đổi mật khẩu
        $this->load->view('sinhvien/doimatkhau');
    }
    
    public function danhsachGV() {
        // Lấy danh sách giảng viên từ Model
        $data['title'] = 'Danh Sách Giảng Viên Hướng Dẫn';
        $data['giangvien_list'] = $this->UserSV_model->get_all_giangvien();
    
        // Lấy thông tin sinh viên từ session để hiển thị
        $data['sinhvien'] = $this->UserSV_model->get_by_tenTK($this->session->userdata('tenTK'));
    
        // Load views
        $this->load->view('sinhvien/header', $data);
        $this->load->view('sinhvien/danhsachGV', $data);
        $this->load->view('sinhvien/footer', $data);
    }
    
    ///////////////////////////////////////

    public function dangkyDetai() {
        $tenTK = $this->session->userdata('tenTK');
        
        if (!$tenTK) {
            redirect('login');
            return;
        }
    
        // Lấy thông tin sinh viên từ tài khoản
        $sinhvien = $this->UserSV_model->get_by_tenTK($tenTK);
        
        if (!$sinhvien) {
            show_error('Không tìm thấy thông tin sinh viên.', 404);
            return;
        }
    
        // Lấy danh sách loại đề tài để lọc
        $data['loaiDT'] = $this->UserSV_model->get_all_loaiDT();
    
        // Kiểm tra nếu có loại đề tài được chọn, nếu không, lấy tất cả đề tài chưa có sinh viên đăng ký.
        $maLDT = $this->input->get('maLDT');  // Lấy mã loại đề tài từ request (nếu có)
        
        // Nếu có mã loại đề tài được chọn, lọc đề tài theo loại đó
        if ($maLDT) {
            $data['detai_chuadk'] = $this->UserSV_model->get_detai_chuadk_by_loaiDT($maLDT);
        } else {
            // Nếu không có loại đề tài, lấy tất cả đề tài chưa có sinh viên đăng ký
            $data['detai_chuadk'] = $this->UserSV_model->get_detai_chuadk();
        }
    
        // Load view đăng ký đề tài
        $data['sinhvien'] = $sinhvien;
        $this->load->view('sinhvien/header', $data);
        $this->load->view('sinhvien/dangkyDetai', $data);
        $this->load->view('sinhvien/footer', $data);
    }
    
    
    
    public function xulyDangkyDetai() {
        $maDT = $this->input->post('maDT');
        $tenTK = $this->session->userdata('tenTK');
    
        if (!$tenTK) {
            redirect('login');
            return;
        }
    
        // Lấy thông tin sinh viên từ tài khoản
        $sinhvien = $this->UserSV_model->get_by_tenTK($tenTK);
    
        if (!$sinhvien) {
            show_error('Không tìm thấy thông tin sinh viên.', 404);
            return;
        }
    
        // Xử lý đăng ký đề tài
        $maSV = $sinhvien->maSV;
        $result = $this->Dangky_model->dangky_detai($maSV, $maDT);
    
        if ($result) {
            $this->session->set_flashdata('success', 'Đăng ký đề tài thành công!');
        } else {
            $this->session->set_flashdata('error', 'Đăng ký thất bại. Bạn đã đăng ký hoặc đề tài không khả dụng.');
        }
    
        redirect('UserSV/dangkyDetai');
    }
    
    public function huyDangkyDetai() {
        $tenTK = $this->session->userdata('tenTK');
    
        if (!$tenTK) {
            redirect('login');
            return;
        }
    
        // Lấy thông tin sinh viên từ tài khoản
        $sinhvien = $this->UserSV_model->get_by_tenTK($tenTK);
    
        if (!$sinhvien) {
            show_error('Không tìm thấy thông tin sinh viên.', 404);
            return;
        }
    
        // Lấy mã đề tài từ yêu cầu POST
        $maDT = $this->input->post('maDT');
    
        if (!$maDT) {
            $this->session->set_flashdata('error', 'Mã đề tài không hợp lệ.');
            redirect('UserSV/index');
            return;
        }
    
        // Hủy đăng ký đề tài
        $result = $this->Dangky_model->huy_dangky($sinhvien->maSV, $maDT);
    
        if ($result) {
            $this->session->set_flashdata('success', 'Hủy đăng ký đề tài thành công.');
        } else {
            $this->session->set_flashdata('error', 'Hủy đăng ký thất bại. Vui lòng thử lại.');
        }
    
        redirect('UserSV/index');
    }
    
}
