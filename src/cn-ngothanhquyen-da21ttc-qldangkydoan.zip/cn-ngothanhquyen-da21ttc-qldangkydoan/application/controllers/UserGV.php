<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class userGV extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->helper('url');
        $this->load->model('UserGV_model');
        $this->load->model('Detai_model');
        $this->load->model('Loaidetai_model');
        $this->load->model('Giangvien_model');
        $this->load->library('session');
        
        
    }

    public function home() {
        $tenTK = $this->session->userdata('tenTK');
    
        if (!$tenTK) {
            redirect('login');
        }
    
        // Lấy thông tin giảng viên dựa trên tenTK
        $giangvien = $this->Giangvien_model->get_giangvien_by_tenTK($tenTK);
    
        if (!$giangvien) {
            $this->session->set_flashdata('error', 'Không tìm thấy thông tin giảng viên.');
            redirect('login');
        }
    
        // Lấy danh sách đề tài đã duyệt của giảng viên
        $approved_topics = $this->Detai_model->get_approved_topics_by_giangvien($giangvien->maGV);
    
        // Truyền dữ liệu qua view
        $data['approved_topics'] = $approved_topics;
        $data['giangvien'] = $giangvien; // Truyền giảng viên vào mảng $data
        $data['detaichuaduyet'] = $this->Detai_model->get_detai_chuaduyet_by_tenTK($giangvien->maGV);
        // Load giao diện
        $this->load->view('giangvien/header', $data); // Truyền $data cho header
        $this->load->view('giangvien/home', $data);
        $this->load->view('giangvien/footer');
    }

    public function doimatkhau() {
        $tenTK = $this->session->userdata('tenTK');
    
        if (!$tenTK) {
            redirect('login');
            return;
        }
    
        $old_password = $this->input->post('old_password');
        $new_password = $this->input->post('new_password');
        $confirm_password = $this->input->post('confirm_password');
    
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // Kiểm tra dữ liệu nhập
            if (empty($old_password) || empty($new_password) || empty($confirm_password)) {
                $this->session->set_flashdata('error', 'Vui lòng nhập đầy đủ thông tin.');
                redirect('UserGV/doimatkhau');
                return;
            }
    
            if ($new_password !== $confirm_password) {
                $this->session->set_flashdata('error', 'Mật khẩu mới và xác nhận mật khẩu không khớp.');
                redirect('UserGV/doimatkhau');
                return;
            }
    
            $giangvien = $this->UserGV_model->get_by_TK($tenTK);
    
            if (!$giangvien || !password_verify($old_password, $giangvien->matkhau)) {
                $this->session->set_flashdata('error', 'Mật khẩu hiện tại không đúng.');
                redirect('UserGV/doimatkhau');
                return;
            }
            if (password_verify($new_password, $giangvien->matkhau)) {
                $this->session->set_flashdata('error', 'Mật khẩu mới không được trùng với mật khẩu hiện tại.');
                redirect('UserGV/doimatkhau');
                return;
            }
            // Cập nhật mật khẩu
            $hashed_password = password_hash($new_password, PASSWORD_BCRYPT);
            $this->UserGV_model->update_password($tenTK, $hashed_password);
    
            $this->session->set_flashdata('success', 'Đổi mật khẩu thành công.');
            redirect('UserGV/index');
            return;
        }
    
        // Load view đổi mật khẩu
        $this->load->view('giangvien/doimatkhau');
    }
    
    public function danhsachGV() {
        // Lấy danh sách giảng viên từ Model
        $data['title'] = 'Danh Sách Giảng Viên Hướng Dẫn';
        $data['giangvien_list'] = $this->UserGV_model->get_all_giangvien();
    
        // Lấy thông tin sinh viên từ session để hiển thị
        $data['giangvien'] = $this->UserGV_model->get_by_tenTK($this->session->userdata('tenTK'));
    
        // Load views
        $this->load->view('giangvien/header', $data);
        $this->load->view('giangvien/danhsachGV', $data);
        $this->load->view('giangvien/footer', $data);
    }
    


    ///////////////////////////////////////////////////////

    public function them_detai() {

        // Lấy thông tin `tenTK` từ session
        $tenTK = $this->session->userdata('tenTK');
    
        if (!$tenTK) {
            // Nếu chưa đăng nhập, chuyển hướng về trang đăng nhập
            redirect('login');
        }
    
        // Lấy thông tin giảng viên dựa vào `tenTK`
        $giangvien = $this->Giangvien_model->get_giangvien_by_tenTK($tenTK);
    
        if (!$giangvien) {
            $this->session->set_flashdata('error', 'Không tìm thấy thông tin giảng viên.');
            redirect('UserGV');
        }
    
        // Nếu form được gửi
        if ($this->input->post()) {
            // Lấy dữ liệu từ form
            $data = [
                'tenDT'        => $this->input->post('tenDT'),
                'mota'         => $this->input->post('mota'),
                'maLDT'        => $this->input->post('maLDT'),
                'maGV'         => $giangvien->maGV, // Lấy mã giảng viên từ thông tin giảng viên
                'trangthaiDuyet' => '0', // Mặc định là chưa duyệt
            ];
    
            // Thêm đề tài thông qua model
            if ($this->Detai_model->insert($data)) {
                $this->session->set_flashdata('success', 'Thêm đề tài thành công!');
            } else {
                $this->session->set_flashdata('error', 'Thêm đề tài thất bại, vui lòng thử lại.');
            }
    
            // Quay lại danh sách đề tài chưa duyệt
            redirect('UserGV');
        } else {
            // Lấy danh sách loại đề tài
            $data['loaiDT'] = $this->Loaidetai_model->get_all();
    
            // Hiển thị view thêm đề tài
            
            $this->load->view('giangvien/themdt', $data);
            
        }
    }
    
    
    public function danhsach_detai() {

        $data['giangvien'] = $this->UserGV_model->get_by_tenTK($this->session->userdata('tenTK'));
    
        // Lấy tất cả các đề tài đã duyệt
        $data['approved_topics'] = $this->UserGV_model->get_approved_topics();
    
        // Hiển thị view danh sách đề tài đã duyệt
        $this->load->view('giangvien/header', $data);
        $this->load->view('giangvien/danhsach_detai', $data);
        $this->load->view('giangvien/footer', $data);
    }
    public function delete($maDT) {
      
       
        // Kiểm tra trước khi xóa
        if ($this->UserGV_model->deleteDetai($maDT)) {
            $this->session->set_flashdata('success', 'Xóa đề tài thành công.');
        } else {
            $this->session->set_flashdata('error', 'Xóa đề tài thất bại.');
        }
    
        // Quay lại trang quản lý đề tài
        redirect('UserGV');
    }
    

    // Controller: UserGV.php

public function sua_detai($maDT) {
    // Lấy thông tin `tenTK` từ session
    $tenTK = $this->session->userdata('tenTK');

    if (!$tenTK) {
        // Nếu chưa đăng nhập, chuyển hướng về trang đăng nhập
        redirect('login');
    }

    // Lấy thông tin giảng viên dựa vào `tenTK`
    $giangvien = $this->Giangvien_model->get_giangvien_by_tenTK($tenTK);

    if (!$giangvien) {
        $this->session->set_flashdata('error', 'Không tìm thấy thông tin giảng viên.');
        redirect('UserGV');
    }

    // Lấy thông tin đề tài từ model
    $data['detai'] = $this->Detai_model->get_by_id($maDT);

    if (!$data['detai']) {
        $this->session->set_flashdata('error', 'Không tìm thấy đề tài.');
        redirect('UserGV');
    }

    // Lấy danh sách loại đề tài
    $data['loaiDT'] = $this->Loaidetai_model->get_all();

    // Nếu form được gửi
    if ($this->input->post()) {
        // Lấy dữ liệu từ form
        $updatedData = [
            'tenDT'        => $this->input->post('tenDT'),
            'mota'         => $this->input->post('mota'),
            'maLDT'        => $this->input->post('maLDT'),
        ];

        // Cập nhật đề tài thông qua model
        if ($this->Detai_model->updateDetai($maDT, $updatedData)) {
            $this->session->set_flashdata('success', 'Cập nhật đề tài thành công!');
            redirect('UserGV');
        } else {
            $this->session->set_flashdata('error', 'Cập nhật đề tài thất bại, vui lòng thử lại.');
        }
    }

    // Hiển thị view sửa đề tài
    $this->load->view('giangvien/suadetai', $data);
}

}
