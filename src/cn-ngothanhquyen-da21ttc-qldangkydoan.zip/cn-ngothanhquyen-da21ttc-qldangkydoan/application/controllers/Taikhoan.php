<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Taikhoan extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Taikhoan_model');
        $this->load->helper('url');
    }

    // Hiển thị danh sách tài khoản
    public function index() {
        $this->load->model('Taikhoan_model');
        $this->load->model('Sinhvien_model');
        $this->load->model('Giangvien_model');
    
        // Lấy danh sách tài khoản và thông tin quyền
        $taikhoans = $this->Taikhoan_model->get_taikhoans_with_roles(); // Lấy thông tin kèm tên quyền
    
        // Duyệt qua từng tài khoản để kiểm tra thêm thông tin
        foreach ($taikhoans as $taikhoan) {
            if ($taikhoan->maQ == 0) { // Quyền sinh viên
                $taikhoan->daThemThongTin = $this->Sinhvien_model->check_exists($taikhoan->maTK);
            } elseif ($taikhoan->maQ == 1) { // Quyền giảng viên
                $taikhoan->daThemThongTin = $this->Giangvien_model->check_exists($taikhoan->maTK);
            } else {
                $taikhoan->daThemThongTin = false;
            }
        }
    
        // Truyền dữ liệu vào View
        $data['taikhoans'] = $taikhoans; // Không ghi đè, giữ lại thông tin tên quyền
        $this->load->view('admin/header', $data);
        $this->load->view('admin/taikhoan_list', $data);
    }
    

    // Thêm tài khoản
    public function add() {
        $this->load->view('admin/taikhoan_add');
    }

    // Lưu tài khoản mới
    public function store() {
        $data = array(
            'tenTK' => $this->input->post('tenTK'),
            'matkhau' => password_hash($this->input->post('matkhau'), PASSWORD_DEFAULT),
            'maQ' => $this->input->post('maQ')
        );
        $this->Taikhoan_model->insert_taikhoan($data);
        redirect('taikhoan');
    }

    // Sửa tài khoản
    public function edit($maTK) {
        $data['taikhoan'] = $this->Taikhoan_model->get_taikhoan_by_id($maTK);
        $this->load->view('admin/taikhoan_edit', $data);
    }

    // Cập nhật tài khoản
    public function update($maTK) {
        $data = array(
            'tenTK' => $this->input->post('tenTK'),
            'matkhau' => password_hash($this->input->post('matkhau'), PASSWORD_DEFAULT),
            'maQ' => $this->input->post('maQ')
        );
        $this->Taikhoan_model->update_taikhoan($maTK, $data);
        redirect('taikhoan');
    }

    // Xóa tài khoản
    public function delete($maTK) {
        $this->Taikhoan_model->delete_taikhoan($maTK);
        redirect('taikhoan');
    }
    
}
