<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Loaidetai extends CI_Controller {

    public function __construct() {
        parent::__construct();
        // Tải model
        $this->load->model('Loaidetai_model');
        $this->load->helper('url');
    }

    // Trang danh sách loại đề tài
    public function index() {
        $data['loaidetais'] = $this->Loaidetai_model->get_all();
        $this->load->view('admin/header', $data);
        $this->load->view('admin/loaidetai_list', $data);
    }

    // Trang thêm loại đề tài
    public function add() {
        $this->load->view('admin/loaidetai_add');
    }

    // Xử lý thêm loại đề tài
    public function add_process() {
        $data = array(
            'maLDT' => $this->input->post('maLDT'),
            'tenLDT' => $this->input->post('tenLDT'),
        );
        $this->Loaidetai_model->insert($data);
        redirect('loaidetai');
    }

    // Trang sửa loại đề tài
    public function edit($maLDT) {
        $data['loaidetai'] = $this->Loaidetai_model->get_by_id($maLDT);
        $this->load->view('admin/loaidetai_edit', $data);
    }

    // Xử lý sửa loại đề tài
    public function edit_process() {
        $data = array(
            'tenLDT' => $this->input->post('tenLDT'),
        );
        $maLDT = $this->input->post('maLDT');
        $this->Loaidetai_model->update($maLDT, $data);
        redirect('loaidetai');
    }

    // Xóa loại đề tài
    public function delete($maLDT) {
        $this->Loaidetai_model->delete($maLDT);
        redirect('loaidetai');
    }
}
