<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Giangvien extends CI_Controller {

    public function __construct() {
        parent::__construct();
        // Tải model
        $this->load->model('Giangvien_model');
        $this->load->helper('url');
    }

    // Trang danh sách giảng viên
    public function index() {
        $data['giangviens'] = $this->Giangvien_model->get_all();
        $this->load->view('admin/header', $data);
        $this->load->view('admin/giangvien_list', $data);
    }

    // Trang thêm giảng viên
    public function add($maTK) {
        $this->load->model('Giangvien_model');
        if ($this->Giangvien_model->check_exists($maTK)) {
            redirect('taikhoan'); // Nếu đã tồn tại thì không cho thêm
        }

        $data['maTK'] = $maTK;
        $this->load->view('admin/giangvien_add', $data);
    }

    public function add_process() {
        $data = array(
            'maGV' => $this->input->post('maGV'),
            'tenGV' => $this->input->post('tenGV'),
            'sdt' => $this->input->post('sdt'),
            'email' => $this->input->post('email'),
            'maTK' => $this->input->post('maTK') // Liên kết với maTK
        );

        $this->load->model('Giangvien_model');
        $this->Giangvien_model->insert($data);

        redirect('taikhoan');
    }

    // Trang sửa giảng viên
    public function edit($maGV) {
        $data['giangvien'] = $this->Giangvien_model->get_by_id($maGV);
        $this->load->view('admin/giangvien_edit', $data);
    }

    // Xử lý sửa giảng viên
    public function edit_process() {
        $data = array(
            'tenGV' => $this->input->post('tenGV'),
            'sdt' => $this->input->post('sdt'),
            'email' => $this->input->post('email'),
            
        );
        $maGV = $this->input->post('maGV');
        $this->Giangvien_model->update($maGV, $data);
        redirect('giangvien');
    }

    // Xóa giảng viên
    public function delete($maGV) {
        $this->Giangvien_model->delete($maGV);
        redirect('giangvien');
    }
}
