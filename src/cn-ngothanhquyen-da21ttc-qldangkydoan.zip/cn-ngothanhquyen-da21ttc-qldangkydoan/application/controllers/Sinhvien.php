<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Sinhvien extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Sinhvien_model');
        $this->load->helper('url');

    }

    // Hiển thị danh sách sinh viên
    public function index() {
        $data['sinhviens'] = $this->Sinhvien_model->get_all_sinhviens();
        $this->load->view('admin/header', $data);
        $this->load->view('admin/sinhvien_list', $data);
        
    }

    // Thêm sinh viên
    public function add($maTK) {
        // Kiểm tra nếu thông tin đã tồn tại
        $this->load->model('Sinhvien_model');
        if ($this->Sinhvien_model->check_exists($maTK)) {
            redirect('taikhoan'); // Nếu đã có thông tin thì quay về danh sách
        }

        $data['maTK'] = $maTK; // Truyền maTK cho form
        $this->load->view('admin/sinhvien_add', $data);
    }

    public function add_process() {
        $data = array(
            'maSV' => $this->input->post('maSV'),
            'tenSV' => $this->input->post('tenSV'),
            'maLop' => $this->input->post('maLop'),
            'sdtSV' => $this->input->post('sdtSV'),
            'emailSV' => $this->input->post('emailSV'),
            'maTK' => $this->input->post('maTK') // Liên kết với maTK
        );

        $this->load->model('Sinhvien_model');
        $this->Sinhvien_model->insert($data);

        redirect('taikhoan');
    }


    
    

    // Sửa sinh viên
    public function edit($maSV) {
        $data['sinhvien'] = $this->Sinhvien_model->get_sinhvien_by_id($maSV);
        $this->load->view('admin/sinhvien_edit', $data);
    }

    public function edit_process($maSV) {
        $data = array(
            'tenSV' => $this->input->post('tenSV'),
            'maLop' => $this->input->post('maLop'),
            'sdtSV' => $this->input->post('sdtSV'),
            'emailSV' => $this->input->post('emailSV')
        );
        $this->Sinhvien_model->update_sinhvien($maSV, $data);
        redirect('sinhvien');
    }

    // Xóa sinh viên
    public function delete($maSV) {
        $this->Sinhvien_model->delete_sinhvien($maSV);
        redirect('sinhvien');
    }
}
