<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Detai extends CI_Controller {

    public function __construct() {
        parent::__construct();
        // Tải model
        $this->load->model('Detai_model');
        $this->load->helper('url');
        
        $this->load->library('session');
    }

    // Hiển thị danh sách đề tài
    public function index() {
        $data['detais'] = $this->Detai_model->get_all();
        $this->load->view('admin/header', $data);
        $this->load->view('admin/detai_list', $data);
    }

    // Thêm đề tài
    public function add() {
        $this->load->model('Loaidetai_model');
        $data['loaiDTS'] = $this->Loaidetai_model->get_all(); // Lấy tất cả các loại đề tài

    // Tải view và truyền dữ liệu
    $this->load->view('admin/detai_add', $data);
    }

    public function add_process() {
        $tenDT = $this->input->post('tenDT');
        $mota = $this->input->post('mota');
        $maGV = $this->input->post('maGV');
        $maLDT = $this->input->post('maLDT');

        // Dữ liệu cần thêm
        $data = array(
            'tenDT' => $tenDT,
            'mota' => $mota,
            'maGV' => $maGV,
            'maLDT' => $maLDT
        );

        // Lưu vào cơ sở dữ liệu
        $this->db->insert('detai', $data);

    // Chuyển hướng về trang danh sách sau khi thêm thành công
    redirect('detai');
    }

    // Sửa đề tài
    public function edit($maDT) {
        $this->load->model('Detai_model');
        $this->load->model('Giangvien_model'); // Model để lấy giảng viên
        $this->load->model('Loaidetai_model');    // Model để lấy loại đề tài
    
        $data['detai'] = $this->Detai_model->get_by_id($maDT); // Lấy thông tin đề tài cần sửa
        $data['giangviens'] = $this->Giangvien_model->get_all(); // Lấy danh sách giảng viên
        $data['loaiDTs'] = $this->Loaidetai_model->get_all(); // Lấy danh sách loại đề tài
    
        $this->load->view('admin/detai_edit', $data); // Truyền dữ liệu sang view sửa
    }
    public function update() {
        $data = array(
            'tenDT' => $this->input->post('tenDT'),
            'mota' => $this->input->post('mota'),
            'maGV' => $this->input->post('maGV'),
            'maLDT' => $this->input->post('maLDT'),
            'trangthaiDuyet' => $this->input->post('trangthaiDuyet') ? 1 : 0,
        );
    
        $this->load->model('Detai_model');
        $this->Detai_model->updateDetai($this->input->post('maDT'), $data);
    
        redirect('detai'); // Quay về danh sách đề tài
    }
    

    public function edit_process() {
        $maDT = $this->input->post('maDT');
        $data = array(
            'tenDT' => $this->input->post('tenDT'),
            'mota' => $this->input->post('mota'),
            'maGV' => $this->input->post('maGV'),
            'maLDT' => $this->input->post('maLDT')
        );
        $this->Detai_model->updateDetai($maDT, $data);
        redirect('detai');
    }

    // Xóa đề tài
    public function delete($maDT) {
        $this->Detai_model->delete($maDT);
        redirect('detai');
    }

    public function approve_ajax() {
        // Load model
        $this->load->model('Detai_model');
    
        // Nhận dữ liệu từ AJAX
        $maDT = $this->input->post('maDT');
        $trangthaiDuyet = $this->input->post('trangthaiDuyet');
    
        // Kiểm tra dữ liệu đầu vào
        if (!isset($maDT) || !isset($trangthaiDuyet)) {
            echo json_encode(['status' => 'error', 'message' => 'Dữ liệu không hợp lệ.']);
            return;
        }
    
        // Chuẩn bị dữ liệu cập nhật
        $data = ['trangthaiDuyet' => $trangthaiDuyet];
    
        // Thực hiện cập nhật qua model
        $result = $this->Detai_model->updateDetai($maDT, $data);
    
        if ($result) {
            echo json_encode(['status' => 'success']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Không thể cập nhật trạng thái.']);
        }
    }
    
    public function thong_ke() {
        // Lấy tất cả các loại đề tài
        $this->load->model('Detai_model');
        $loaiDTs = $this->Detai_model->get_all_loaiDT();
    
        // Khởi tạo mảng để lưu kết quả
        $data['loaiDTs'] = [];
    
        foreach ($loaiDTs as $loaiDT) {
            // Lấy danh sách đề tài cho mỗi loại đề tài
            $detais = $this->Detai_model->get_detai_by_loai($loaiDT->maLDT);
    
            // Lấy thông tin giảng viên và sinh viên đăng ký cho từng đề tài
            foreach ($detais as &$detai) {
                // Lấy giảng viên
                $detai->giangvien = $this->Detai_model->get_giangvien_by_id($detai->maGV);
                
                // Lấy sinh viên đăng ký
                $detai->sinhvien = $this->Detai_model->get_sinhvien_by_detai($detai->maDT);
            }
    
            // Lưu kết quả của mỗi loại đề tài
            $data['loaiDTs'][] = [
                'loaiDT' => $loaiDT,
                'detais' => $detais
            ];
        }
    
        // Trả kết quả về view
        $this->load->view('admin/header', $data);
        $this->load->view('admin/thongke', $data);
    }
    
    //////////////////////////////////////////
  
}
