<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {
    public function __construct()
    {
        parent::__construct();
        $this->load->model('LoginModel');
        $this->load->helper('url');
        $this->load->library('session'); // Load thư viện session
    }
    public function index() {
        $this->load->view('login');
    }

    // Xử lý đăng nhập
    public function process() {
        $tenTK = $this->input->post('tenTK');
        $matkhau = $this->input->post('matkhau');

        // Gọi model để kiểm tra tài khoản
        $user = $this->LoginModel->get_user_by_username($tenTK);

        if ($user) {
            // So khớp mật khẩu
            if (password_verify($matkhau, $user->matkhau)) {
                // Lưu session và chuyển hướng
                $this->session->set_userdata('tenTK', $user->tenTK);
                $this->session->set_userdata('maQ', $user->maQ);
                switch ($user->maQ) {
                    case '0': // Sinh viên
                        redirect(base_url('UserSV'));
                        break;
                    case '1': // Giảng viên
                        redirect(base_url('UserGV'));
                        break;
                    case '2': // Admin
                        redirect(base_url('taikhoan'));
                        break;
                    default:
                        $this->session->set_flashdata('error', 'Quyền không hợp lệ!');
                        redirect(base_url('login'));
            }
         } else {
                $this->session->set_flashdata('error', 'Sai mật khẩu!');
            }
        } else {
            $this->session->set_flashdata('error', 'Tài khoản không tồn tại!');
        }

        redirect(base_url('login'));
    }

    // Đăng xuất
    public function logout() {
        $this->session->sess_destroy();
        redirect('login');
    }
}
